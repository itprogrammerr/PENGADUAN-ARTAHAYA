<footer class="mt-3 p-3 text-center bg-white text-sm text-gray-600 dark:text-gray-400 dark:bg-gray-800">
  © 2022 PENGADUAN NASABAH BANK ANJUK LADANG | By
    <a class="text-blue-500" target="_blank">IT ANJUK LADANG</a>
</footer><?php /**PATH C:\xampp\htdocs\aduan\resources\views/includes/admin/footer.blade.php ENDPATH**/ ?>